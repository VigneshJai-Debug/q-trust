"""GPU-accelerated GNN training — 100K graphs, BF16 mixed precision, larger model.

This is the drop-in replacement for train.py that uses the A100 GPU properly:

  - 100,000 synthetic training graphs (vs 1,200 in train.py)
  - 200 epochs (vs 50 in train.py)
  - Larger model: 256-dim hidden, 128-dim embedding, 8 attention heads (vs 64/32/4)
  - BF16 mixed-precision training (2x speedup on A100)
  - Batch size 256 (vs 32) — A100 has 40GB VRAM
  - Saves to model_gpu_v3.pt

Expected wall time on A100 40GB: ~4 hours for 200 epochs on 100K graphs.

Usage:
    cd planner
    python -m qtrust_planner.train_gpu
    python -m qtrust_planner.train_gpu --epochs 50 --n-graphs 10000  # quick test
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.loader import DataLoader

if __package__ in (None, ""):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from model_v3 import MigrationGNNv3
    from data_generator import generate_dataset
else:
    from .model_v3 import MigrationGNNv3
    from .data_generator import generate_dataset


def listMLE_loss(order_logits: torch.Tensor, y_order: torch.Tensor) -> torch.Tensor:
    """ListMLE ranking loss (Plackett-Luce likelihood).

    Args:
        order_logits: (N,) predicted priority scores.
        y_order: (N,) ground-truth rank of each node (0 = first to migrate).

    Returns:
        Scalar loss (lower = better).
    """
    # Convert ranks to permutation: sort nodes by ground-truth rank
    # y_order[i] = rank of node i (0 = highest priority)
    # We want to maximize the likelihood of the correct ordering
    perm = torch.argsort(y_order)
    scores = order_logits[perm]

    # ListMLE: -sum(log(softmax(scores[i:]) for i in range(N)))
    max_val = scores.max()
    scores = scores - max_val  # numerical stability
    cumsum = torch.cumsum(scores.flip(0), dim=0).flip(0)
    log_cumsum = torch.log(cumsum + 1e-10)
    loss = -(scores - log_cumsum).sum()
    return loss


def compute_metrics(order_logits: torch.Tensor, y_order: torch.Tensor) -> dict:
    """Compute ranking metrics: Kendall τ, top-5 overlap, top-10 overlap."""
    # Kendall tau
    n = len(order_logits)
    pred_ranks = torch.argsort(torch.argsort(order_logits, descending=True)).float()
    true_ranks = y_order.float()

    # Simple Kendall tau (O(n^2) but fine for n < 200)
    concordant = 0
    discordant = 0
    for i in range(n):
        for j in range(i + 1, n):
            pred_diff = pred_ranks[i] - pred_ranks[j]
            true_diff = true_ranks[i] - true_ranks[j]
            if (pred_diff > 0 and true_diff > 0) or (pred_diff < 0 and true_diff < 0):
                concordant += 1
            elif pred_diff != 0 and true_diff != 0:
                discordant += 1

    total_pairs = n * (n - 1) / 2
    kendall = (concordant - discordant) / max(total_pairs, 1)

    # Top-k overlap
    top5_pred = set(torch.argsort(order_logits, descending=True)[:5].tolist())
    top5_true = set(torch.argsort(y_order)[:5].tolist())
    top5_overlap = len(top5_pred & top5_true) / min(5, n)

    top10_pred = set(torch.argsort(order_logits, descending=True)[:10].tolist())
    top10_true = set(torch.argsort(y_order)[:10].tolist())
    top10_overlap = len(top10_pred & top10_true) / min(10, n)

    return {
        "kendall": float(kendall),
        "top5": float(top5_overlap),
        "top10": float(top10_overlap),
    }


def train_gpu(
    n_graphs: int = 100_000,
    epochs: int = 200,
    batch_size: int = 256,
    learning_rate: float = 1e-3,
    weight_decay: float = 1e-4,
    model_path: str = "planner/model_gpu_v3.pt",
    seed: int = 42,
    val_split: float = 0.1,
) -> str:
    """Train the MigrationGNNv3 on GPU with mixed precision.

    Args:
        n_graphs: Number of synthetic training graphs (default 100K).
        epochs: Number of training epochs (default 200).
        batch_size: Mini-batch size (default 256 — A100 can handle this).
        learning_rate: Adam learning rate (default 1e-3).
        weight_decay: AdamW weight decay (default 1e-4).
        model_path: Where to save the trained model.
        seed: RNG seed.
        val_split: Fraction of data for validation (default 0.1 = 10K graphs).

    Returns:
        The path the model was saved to.
    """
    if not torch.cuda.is_available():
        raise RuntimeError(
            "GPU not available. This script requires CUDA. "
            "Run on a BrevLab instance with NVIDIA GPU."
        )

    device = torch.device("cuda")
    torch.cuda.empty_cache()
    torch.manual_seed(seed)

    print(f"Device: {torch.cuda.get_device_name(0)}")
    print(f"GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    print(f"Generating {n_graphs:,} synthetic graphs...")
    gen_start = time.time()
    dataset = generate_dataset(n_graphs=n_graphs, seed=seed)
    print(f"Generation took {time.time() - gen_start:.1f}s")

    # Train/val split
    n_val = int(n_graphs * val_split)
    n_train = n_graphs - n_val
    train_dataset = dataset[:n_train]
    val_dataset = dataset[n_train:]
    print(f"Train: {n_train:,} graphs, Val: {n_val:,} graphs")

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=4)

    # Larger model
    model = MigrationGNNv3(
        input_features=6,
        hidden_dim=256,
        embedding_dim=128,
        heads=8,
        dropout=0.15,
        use_centrality=True,
        variant="hybrid",
    ).to(device)

    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {n_params:,} (v2 had ~50K, v3 has ~{n_params/1000:.0f}K)")

    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay=weight_decay)
    scaler = torch.cuda.amp.GradScaler()  # for FP16 gradient scaling

    best_val_kendall = -1.0
    train_start = time.time()

    for epoch in range(epochs):
        # --- Training ---
        model.train()
        total_loss = 0
        n_batches = 0

        for batch in train_loader:
            batch = batch.to(device)
            optimizer.zero_grad()

            # Mixed-precision forward pass (BF16 on A100)
            with torch.cuda.amp.autocast(dtype=torch.bfloat16):
                order_logits, risk_logits = model(batch)
                # Order loss: ListMLE
                loss_order = listMLE_loss(order_logits, batch.y)
                # Risk loss: MSE (risk should correlate with criticality)
                loss_risk = F.mse_loss(risk_logits, batch.y.float()) if hasattr(batch, "y") else torch.tensor(0.0, device=device)
                loss = loss_order + 0.3 * loss_risk

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()

            total_loss += loss.item()
            n_batches += 1

        avg_train_loss = total_loss / max(n_batches, 1)

        # --- Validation ---
        if (epoch + 1) % 10 == 0 or epoch == 0:
            model.eval()
            all_metrics = {"kendall": [], "top5": [], "top10": []}

            with torch.no_grad():
                for batch in val_loader:
                    batch = batch.to(device)
                    with torch.cuda.amp.autocast(dtype=torch.bfloat16):
                        order_logits, _ = model(batch)
                    metrics = compute_metrics(order_logits, batch.y)
                    all_metrics["kendall"].append(metrics["kendall"])
                    all_metrics["top5"].append(metrics["top5"])
                    all_metrics["top10"].append(metrics["top10"])

            avg_kendall = sum(all_metrics["kendall"]) / len(all_metrics["kendall"])
            avg_top5 = sum(all_metrics["top5"]) / len(all_metrics["top5"])
            avg_top10 = sum(all_metrics["top10"]) / len(all_metrics["top10"])

            gpu_mem = torch.cuda.memory_allocated() / 1e9
            elapsed = time.time() - train_start
            print(
                f"Epoch {epoch+1:>3}/{epochs} | "
                f"loss={avg_train_loss:.4f} | "
                f"val τ={avg_kendall:.4f} top5={avg_top5:.3f} top10={avg_top10:.3f} | "
                f"GPU={gpu_mem:.1f}GB | "
                f"elapsed={elapsed:.0f}s"
            )

            if avg_kendall > best_val_kendall:
                best_val_kendall = avg_kendall
                torch.save(model.state_dict(), model_path)
                print(f"  → Saved best model (τ={best_val_kendall:.4f})")

    total_time = time.time() - train_start
    print(f"\nTraining complete in {total_time:.0f}s ({total_time/60:.1f} min)")
    print(f"Best validation Kendall τ: {best_val_kendall:.4f}")
    print(f"Model saved to: {model_path}")
    return model_path


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="GPU-accelerated GNN training")
    parser.add_argument("--epochs", type=int, default=200, help="Number of epochs")
    parser.add_argument("--n-graphs", type=int, default=100_000, help="Number of training graphs")
    parser.add_argument("--batch-size", type=int, default=256, help="Batch size")
    parser.add_argument("--lr", type=float, default=1e-3, help="Learning rate")
    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument("--quick", action="store_true", help="Quick test: 10K graphs, 20 epochs")
    args = parser.parse_args()

    if args.quick:
        args.n_graphs = 10_000
        args.epochs = 20

    train_gpu(
        n_graphs=args.n_graphs,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        seed=args.seed,
    )
