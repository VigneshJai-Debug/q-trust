/**
 * GPU service — Fastify route handlers for GPU-accelerated features.
 *
 * Exposes:
 *   POST /v1/gpu/side-channel/analyze     — analyze a PQC implementation
 *   POST /v1/gpu/anomaly/score            — score a CBOM for anomalies
 *   GET  /v1/gpu/quantum/estimate/:bits   — estimate quantum threat for RSA-n
 *   POST /v1/gpu/scan/parallel            — parallel enterprise scan
 *   GET  /v1/gpu/rl/plan                  — RL-based migration plan
 *   GET  /v1/gpu/status                   — GPU availability and model info
 *
 * All GPU operations are optional — if no GPU is available, routes return
 * 503 with a helpful message.
 */
import type { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import * as dotenv from "dotenv";

dotenv.config();

const execFileAsync = promisify(execFile);

const PLANNER_URL = process.env.QTRUST_PLANNER_URL ?? "http://127.0.0.1:8000";
const GPU_ENABLED = process.env.QTRUST_GPU_ENABLED === "true";

interface GPUStatus {
  available: boolean;
  device_name: string | null;
  memory_total_gb: number | null;
  models_loaded: string[];
}

let cachedStatus: GPUStatus | null = null;

async function checkGPU(): Promise<GPUStatus> {
  if (cachedStatus) return cachedStatus;

  try {
    const { stdout } = await execFileAsync("python3", ["-c", `
import torch
import json
if torch.cuda.is_available():
    props = torch.cuda.get_device_properties(0)
    print(json.dumps({
        "available": True,
        "device_name": props.name,
        "memory_total_gb": props.total_memory / 1e9,
        "models_loaded": []
    }))
else:
    print(json.dumps({
        "available": False,
        "device_name": None,
        "memory_total_gb": None,
        "models_loaded": []
    }))
`], { timeout: 5000 });
    cachedStatus = JSON.parse(stdout.trim());
    return cachedStatus!;
  } catch {
    cachedStatus = {
      available: false,
      device_name: null,
      memory_total_gb: null,
      models_loaded: [],
    };
    return cachedStatus;
  }
}

export async function registerGPURoutes(server: FastifyInstance): Promise<void> {
  // ------------------------------------------------------------------
  // GPU status
  // ------------------------------------------------------------------
  server.get("/v1/gpu/status", async () => {
    const status = await checkGPU();
    return {
      ...status,
      gpu_enabled: GPU_ENABLED,
      planner_url: PLANNER_URL,
    };
  });

  // ------------------------------------------------------------------
  // Side-channel analysis
  // ------------------------------------------------------------------
  server.post("/v1/gpu/side-channel/analyze", async (request: FastifyRequest, reply: FastifyReply) => {
    const body = request.body as {
      implementation_cmd?: string[];
      n_traces?: number;
      simulated?: boolean;
      leakage_prob?: number;
    };

    if (!GPU_ENABLED) {
      return reply.code(503).send({
        error: "GPU features not enabled. Set QTRUST_GPU_ENABLED=true.",
      });
    }

    try {
      const args = [
        "-c",
        `
import json
from qtrust_inspector.side_channel import SideChannelAnalyzer

analyzer = SideChannelAnalyzer()

if ${body.simulated ?? false}:
    result = analyzer.analyze_simulated(
        leakage_prob=${body.leakage_prob ?? 0.0},
        n_traces=${body.n_traces ?? 10000}
    )
else:
    result = analyzer.analyze_implementation(
        ${JSON.stringify(body.implementation_cmd)},
        n_traces=${body.n_traces ?? 10000}
    )

print(json.dumps({
    "implementation": result.implementation,
    "traces_collected": result.traces_collected,
    "leakage_probability": result.leakage_probability,
    "verdict": result.verdict,
    "evidence_hash": result.evidence_hash,
    "timestamp": result.timestamp,
    "gpu_used": result.gpu_used,
}))
`,
      ];

      const { stdout } = await execFileAsync("python3", args, {
        timeout: 300000, // 5 minutes
        cwd: "/app",
      });

      return JSON.parse(stdout.trim());
    } catch (err) {
      request.log.error(err);
      return reply.code(500).send({
        error: "Side-channel analysis failed",
        detail: String(err),
      });
    }
  });

  // ------------------------------------------------------------------
  // Anomaly detection
  // ------------------------------------------------------------------
  server.post("/v1/gpu/anomaly/score", async (request: FastifyRequest, reply: FastifyReply) => {
    const body = request.body as { cbom?: Record<string, unknown> };

    if (!body.cbom) {
      return reply.code(400).send({ error: "cbom is required" });
    }

    if (!GPU_ENABLED) {
      return reply.code(503).send({
        error: "GPU features not enabled. Set QTRUST_GPU_ENABLED=true.",
      });
    }

    try {
      const cbomJson = JSON.stringify(body.cbom);
      const { stdout } = await execFileAsync("python3", [
        "-c",
        `
import json
from qtrust_inspector.anomaly_detector import CBOMAnomalyDetector

cbom = json.loads('''${cbomJson.replace(/'/g, "\\'")}''')
detector = CBOMAnomalyDetector()
result = detector.score_cbom(cbom)
print(json.dumps({
    "anomaly_score": result.anomaly_score,
    "is_anomalous": result.is_anomalous,
    "threshold": result.threshold,
    "asset_count": result.asset_count,
    "top_anomalous_assets": result.top_anomalous_assets,
    "evidence_hash": result.evidence_hash,
    "timestamp": result.timestamp,
}))
`,
      ], { timeout: 60000, cwd: "/app" });

      return JSON.parse(stdout.trim());
    } catch (err) {
      request.log.error(err);
      return reply.code(500).send({
        error: "Anomaly detection failed",
        detail: String(err),
      });
    }
  });

  // ------------------------------------------------------------------
  // Quantum threat estimation
  // ------------------------------------------------------------------
  server.get("/v1/gpu/quantum/estimate/:bits", async (request: FastifyRequest, reply: FastifyReply) => {
    const { bits } = request.params as { bits: string };
    const nBits = parseInt(bits, 10);

    if (isNaN(nBits) || nBits < 512 || nBits > 16384) {
      return reply.code(400).send({ error: "bits must be between 512 and 16384" });
    }

    try {
      const { stdout } = await execFileAsync("python3", [
        "-c",
        `
from qtrust_planner.quantum_estimator import QuantumThreatEstimator
import json

est = QuantumThreatEstimator()
result = est.estimate_qubits_for_rsa(${nBits})
print(json.dumps({
    "rsa_key_size": result.rsa_key_size,
    "logical_qubits_needed": result.logical_qubits_needed,
    "physical_qubits_needed": result.physical_qubits_needed,
    "estimated_breakable_year": result.estimated_breakable_year,
    "based_on": result.based_on,
}))
`,
      ], { timeout: 10000, cwd: "/app" });

      return JSON.parse(stdout.trim());
    } catch (err) {
      request.log.error(err);
      return reply.code(500).send({
        error: "Quantum estimation failed",
        detail: String(err),
      });
    }
  });

  // ------------------------------------------------------------------
  // RL-based migration plan (proxied to planner microservice)
  // ------------------------------------------------------------------
  server.post("/v1/gpu/rl/plan", async (request: FastifyRequest, reply: FastifyReply) => {
    const body = request.body as { cbom?: Record<string, unknown> };

    if (!body.cbom) {
      return reply.code(400).send({ error: "cbom is required" });
    }

    try {
      const resp = await fetch(`${PLANNER_URL}/rl/plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body.cbom),
      });

      if (!resp.ok) {
        throw new Error(`Planner returned ${resp.status}`);
      }

      return await resp.json();
    } catch (err) {
      request.log.error(err);
      return reply.code(503).send({
        error: "RL planner not available. Ensure planner microservice is running.",
        detail: String(err),
      });
    }
  });
}
