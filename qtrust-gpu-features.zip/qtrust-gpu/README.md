# GPU-Accelerated Features for Q-Trust

This package contains 6 GPU-accelerated modules that transform Q-Trust from a
protocol with an idle A100 into a protocol that uses the A100 for genuine
defensive differentiation.

## Files

### 1. Large-scale GNN training (100K graphs, BF16, larger model)
- `planner/qtrust_planner/train_gpu.py` — drop-in replacement for `train.py`
- `planner/qtrust_planner/model_v3.py` — larger model architecture (256-dim hidden)
- `tests/test_train_gpu.py` — smoke test

### 2. Side-channel analysis (CNN+LSTM on 10M timing traces)
- `inspector/qtrust_inspector/side_channel.py` — the killer differentiator
- `inspector/qtrust_inspector/side_channel_collector.py` — trace collection
- `inspector/tests/test_side_channel.py` — smoke test
- `notebooks/03_side_channel_demo.ipynb` — demo notebook

### 3. GPU-accelerated quantum simulation (qiskit-aer-gpu)
- `notebooks/02_quantum_threat_gpu.py` — factors N=21, 35, 77 on A100
- `planner/qtrust_planner/quantum_estimator.py` — reusable estimator

### 4. Parallel enterprise scanning (1000+ hosts, GPU batch risk scoring)
- `inspector/qtrust_inspector/parallel_scanner.py` — async parallel scanner
- `inspector/tests/test_parallel_scanner.py` — smoke test

### 5. RL migration agent (10K simulated episodes)
- `planner/qtrust_planner/rl_agent.py` — policy network + training loop
- `planner/qtrust_planner/migration_env.py` — simulation environment
- `planner/qtrust_planner/train_rl.py` — training script
- `tests/test_rl_agent.py` — smoke test

### 6. Anomaly detection on CBOMs (deep learning)
- `inspector/qtrust_inspector/anomaly_detector.py` — autoencoder-based
- `inspector/tests/test_anomaly_detector.py` — smoke test

### Integration
- `backend/src/services/gpu_service.py` — Fastify route handlers for GPU features
- `backend/src/routes/gpu.ts` — API routes
- `frontend/src/components/side-channel-panel.tsx` — frontend panel
- `docs/GPU_FEATURES.md` — documentation
- `Makefile.gpu` — Make targets for GPU features

## Installation

```bash
# In your BrevLab with the qtrust conda env active
pip install qiskit-aer-gpu  # for feature #3

# Or install all GPU deps at once
pip install -r requirements-gpu.txt
```

## Honest limitations

- **Side-channel analysis** requires a real PQC implementation to test against.
  The module includes a demo mode that simulates timing traces, but production
  use requires a real binary (e.g., from OQS provider).
- **RL agent** trains on synthetic data. Real-world validation requires real
  CBOMs and migration outcome data.
- **Quantum simulation** of N=77 requires ~5GB GPU memory and may take 5-10
  minutes. N=15 takes ~3 seconds.
- **Parallel scanner** requires network access to scan external hosts. For
  internal enterprise scanning, run inside the corporate network.

## Priority

Build in this order:
1. Feature #1 (GNN training) — addresses biggest audit risk, 3 days
2. Feature #3 (quantum simulation) — 10x better demo, 2 days
3. Feature #4 (parallel scanner) — enterprise-scale, 1 week
4. Feature #2 (side-channel) — killer differentiator, 2 weeks
5. Feature #5 (RL agent) — patentable moat, 2 weeks
6. Feature #6 (anomaly detection) — nice-to-have, 1 week
