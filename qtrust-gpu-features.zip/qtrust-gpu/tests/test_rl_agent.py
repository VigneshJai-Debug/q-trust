"""Smoke test for the RL migration agent.

Verifies the environment and policy network work.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
from qtrust_planner.rl_agent import (
    MigrationEnvironment,
    MigrationAgent,
    state_to_tensors,
    train_agent,
)


def test_environment():
    """Test the migration simulation environment."""
    env = MigrationEnvironment(n_assets=10, seed=42)
    state = env.reset()

    assert len(state.assets) == 10
    assert len(state.available) > 0  # at least one asset should be available
    assert state.elapsed_days == 0

    # Take a step
    action = state.available[0]
    next_state, reward, done, info = env.step(action)

    assert next_state.migrated[action] == True
    assert isinstance(reward, float)
    assert isinstance(done, bool)

    print("✓ Migration environment correct")


def test_agent_construction():
    """Test the policy network."""
    agent = MigrationAgent(n_features=6, hidden_dim=64)

    n_params = sum(p.numel() for p in agent.parameters())
    print(f"Agent parameters: {n_params:,}")

    # Create dummy state
    env = MigrationEnvironment(n_assets=10, seed=42)
    state = env.reset()

    device = torch.device("cpu")
    x, edge_index = state_to_tensors(state, str(device))

    policy_logits, state_value = agent(x, edge_index)
    assert policy_logits.shape == (10,), f"Expected (10,), got {policy_logits.shape}"
    assert state_value.shape == (1,) or state_value.dim() == 0

    print("✓ RL agent forward pass correct")


def test_agent_training_quick():
    """Quick training test (10 episodes)."""
    # This should complete in <1 minute on CPU
    agent = train_agent(n_episodes=10, save_path="/tmp/rl_agent_test.pt")
    assert agent is not None

    # Verify model was saved
    assert os.path.exists("/tmp/rl_agent_test.pt")
    os.remove("/tmp/rl_agent_test.pt")

    print("✓ RL agent training (10 episodes) correct")


if __name__ == "__main__":
    test_environment()
    test_agent_construction()
    test_agent_training_quick()
    print("\nAll RL agent tests passed!")
