"""Smoke test for the anomaly detector."""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
from qtrust_inspector.anomaly_detector import (
    CBOMVariationalAutoencoder,
    CBOMAnomalyDetector,
)


def test_vae_construction():
    """Test VAE model construction and forward pass."""
    model = CBOMVariationalAutoencoder(n_features=10, latent_dim=16)
    x = torch.randn(8, 10)  # batch=8, features=10
    recon, mu, logvar = model(x)

    assert recon.shape == (8, 10), f"Expected (8, 10), got {recon.shape}"
    assert mu.shape == (8, 16), f"Expected (8, 16), got {mu.shape}"
    assert logvar.shape == (8, 16), f"Expected (8, 16), got {logvar.shape}"
    print("✓ VAE forward pass correct")


def test_feature_extraction():
    """Test CBOM feature extraction."""
    detector = CBOMAnomalyDetector()
    cbom = {
        "assets": [
            {"algorithm": "RSA-2048", "key_size": 2048, "criticality": "high",
             "expired": False, "vendor": "DigiCert", "self_signed": False,
             "days_until_expiry": 90, "location": "host1.com"},
            {"algorithm": "ECC-P256", "key_size": 256, "criticality": "medium",
             "expired": False, "vendor": "Let's Encrypt", "self_signed": False,
             "days_until_expiry": 30, "location": "host2.com"},
        ]
    }
    features = detector._extract_features(cbom)
    assert features.shape == (2, 10), f"Expected (2, 10), got {features.shape}"
    print("✓ Feature extraction correct")


def test_anomaly_scoring():
    """Test anomaly scoring on a normal and anomalous CBOM."""
    detector = CBOMAnomalyDetector()

    # Generate training data
    training_cboms = detector.generate_synthetic_training_data(n_cboms=100, n_assets_per_cbom=20)

    # Train (quick)
    detector.train(training_cboms, epochs=20, save_path="/tmp/anomaly_test.pt")

    # Test on normal CBOM
    normal_result = detector.score_cbom(training_cboms[0])
    assert 0 <= normal_result.anomaly_score <= 1
    print(f"✓ Normal CBOM: score={normal_result.anomaly_score:.4f}, anomalous={normal_result.is_anomalous}")

    # Test on anomalous CBOM (many weak RSA-1024 keys, expired, self-signed)
    anomalous_cbom = {
        "assets": [
            {"algorithm": "RSA-1024", "key_size": 1024, "criticality": "critical",
             "expired": True, "vendor": None, "self_signed": True,
             "days_until_expiry": 0, "location": "bad-host.com"}
            for _ in range(10)
        ]
    }
    anomalous_result = detector.score_cbom(anomalous_cbom)
    print(f"✓ Anomalous CBOM: score={anomalous_result.anomaly_score:.4f}, anomalous={anomalous_result.is_anomalous}")

    # Clean up
    if os.path.exists("/tmp/anomaly_test.pt"):
        os.remove("/tmp/anomaly_test.pt")


if __name__ == "__main__":
    test_vae_construction()
    test_feature_extraction()
    test_anomaly_scoring()
    print("\nAll anomaly detector tests passed!")
