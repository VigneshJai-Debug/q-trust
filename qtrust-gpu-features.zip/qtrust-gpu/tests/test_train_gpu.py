"""Smoke test for GPU GNN training.

Verifies the v3 model and training loop work with a tiny dataset.
Does NOT require a GPU (falls back to CPU).
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
from qtrust_planner.model_v3 import MigrationGNNv3, build_node_features_v3


def test_model_v3_construction():
    """Test that the v3 model constructs and forward passes."""
    model = MigrationGNNv3(
        input_features=6,
        hidden_dim=64,  # small for test
        embedding_dim=32,
        heads=4,
        dropout=0.15,
        use_centrality=True,
        variant="hybrid",
    )

    n_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {n_params:,}")
    assert n_params > 0, "Model should have parameters"

    # Create a dummy graph
    from torch_geometric.data import Data
    x = torch.randn(10, 6)  # 10 nodes, 6 features
    edge_index = torch.tensor([[0, 1, 2, 3], [1, 2, 3, 4]], dtype=torch.long)
    data = Data(x=x, edge_index=edge_index)

    order_logits, risk_logits = model(data)

    assert order_logits.shape == (10,), f"Expected (10,), got {order_logits.shape}"
    assert risk_logits.shape == (10,), f"Expected (10,), got {risk_logits.shape}"
    print("✓ Model v3 forward pass correct")


def test_node_features_v3():
    """Test node feature construction."""
    features = build_node_features_v3(
        algorithm_type=0,  # RSA
        key_size=2048,
        vendor_pqc_ready=False,
        criticality=3,  # high
        days_to_deadline=365.0,
        required_rate=0.5,
    )
    assert features.shape == (6,), f"Expected (6,), got {features.shape}"
    assert all(0 <= v <= 1 for v in features), "Features should be normalized"
    print("✓ Node features v3 correct")


if __name__ == "__main__":
    test_model_v3_construction()
    test_node_features_v3()
    print("\nAll GPU GNN tests passed!")
