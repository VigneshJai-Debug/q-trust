"""Smoke test for side-channel analysis.

Verifies the CNN+LSTM detector and trace collection work.
Does NOT require a real PQC implementation (uses simulated traces).
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import torch
from qtrust_inspector.side_channel import (
    SideChannelDetector,
    SideChannelAnalyzer,
    simulate_timing_traces,
)


def test_detector_construction():
    """Test CNN+LSTM model construction."""
    model = SideChannelDetector(trace_length=1000)

    # Create dummy input
    x = torch.randn(4, 1, 1000)  # batch=4, channel=1, length=1000
    output = model(x)

    assert output.shape == (4,), f"Expected (4,), got {output.shape}"
    assert all(0 <= v <= 1 for v in output), "Output should be probabilities"
    print("✓ Side-channel detector forward pass correct")


def test_simulated_traces():
    """Test simulated trace generation."""
    traces = simulate_timing_traces(n_traces=100, leakage_prob=0.0, seed=42)
    assert len(traces) == 100
    assert abs(traces.mean()) < 0.1  # approximately zero-mean
    print("✓ Simulated trace generation correct")


def test_analyzer_simulated():
    """Test the full analyzer with simulated traces."""
    analyzer = SideChannelAnalyzer()

    # Test clean implementation (no leakage)
    result = analyzer.analyze_simulated(leakage_prob=0.0, n_traces=1000, seed=42)
    assert result.verdict in ["SIDE_CHANNEL_VERIFIED", "SIDE_CHANNEL_LOW_RISK", "SIDE_CHANNEL_HIGH_RISK"]
    assert 0.0 <= result.leakage_probability <= 1.0
    assert len(result.evidence_hash) == 66  # 0x + 64 hex chars
    print(f"✓ Clean implementation: prob={result.leakage_probability:.4f}, verdict={result.verdict}")

    # Test leaking implementation
    result = analyzer.analyze_simulated(leakage_prob=0.8, n_traces=1000, seed=43)
    assert result.verdict in ["SIDE_CHANNEL_VERIFIED", "SIDE_CHANNEL_LOW_RISK", "SIDE_CHANNEL_HIGH_RISK"]
    print(f"✓ Leaking implementation: prob={result.leakage_probability:.4f}, verdict={result.verdict}")


if __name__ == "__main__":
    test_detector_construction()
    test_simulated_traces()
    test_analyzer_simulated()
    print("\nAll side-channel tests passed!")
